
<section class="section-content  ">
    <div class="container">

        <br>
        <nav aria-label="breadcrumb text-white">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/" class="link"> <?php echo e(trans('message.home')); ?></a></li>
                <li class="breadcrumb-item active"><span> <?php echo e(trans('footer.Contact_us')); ?></span></li>

            </ol>
        </nav>



        <!-- ============================ COMPONENT 1 ================================= -->
        <div class="card">
            <div class="row no-gutters">
                <aside class="col-md-6" >
                    <h2 class="card-title mb-4 " style="margin: 20px;;"><?php echo e(trans('message.LeaveaMessage')); ?></h2>
                    <?php if(Session::has('message')): ?>
                        <div class="alert alert-success" role="alert"><?php echo e(Session::get('message')); ?></div>
                    <?php endif; ?>

                    <form  wire:submit.prevent="sendMessage" style="margin: 20px;;">
                        <div class="form-group">
                        <label for="name"><?php echo e(trans('message.Name')); ?><span>*</span></label>
                        <input type="text" class="form-control" value="" id="name" name="name" wire:model="name" >
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                        <label for="email"><?php echo e(trans('message.Email')); ?><span>*</span></label>
                        <input type="text" class="form-control" value="" id="email" name="email" wire:model="email"  >
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                        <label for="phone"><?php echo e(trans('footer.Phone')); ?></label>
                        <input type="text" class="form-control" value="" id="phone" name="phone" wire:model="phone" >
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>

                        <div class="form-group">

                        <label for="comment"><?php echo e(trans('message.Comment')); ?></label>
                        <textarea name="comment" class="form-control" rows="3" id="comment" wire:model="comment" ></textarea>
                        <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>

                        <div class="form-group">
                            <input type="submit"  class="btn btn-primary btn-block" name="ok" value="<?php echo e(trans('message.Send')); ?>" >
                        </div> <!-- form-group// -->
                    </form>



                </aside>




                <main class="col-md-6 border-left">
                    <article class="content-body">

                        <iframe  width="100%" height="320" style="border:0;" allowfullscreen="" loading="lazy" src="<?php echo e($setting->map); ?>" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>

                        <hr>

                        <h4 class="title "><?php echo e(trans('message.ContactDetail')); ?> </h4>



                        <div class="wrap-icon-box">
                            <div class="icon-box-item">
                                <i class="fa fa-envelope" aria-hidden="true"></i>
                                <div class="right-info">
                                    <b><?php echo e(trans('message.Email')); ?></b>
                                    <p class="contact-txt"><?php echo e($setting->email); ?></p>
                                </div>
                            </div>

                            <div class="icon-box-item">
                                <i class="fa fa-phone" aria-hidden="true"></i>
                                <div class="right-info">
                                    <b><?php echo e(trans('footer.Phone')); ?></b>
                                    <p><?php echo e($setting->phone); ?> || <?php echo e($setting->phone2); ?></p>
                                </div>
                            </div>

                            <div class="icon-box-item">
                                <i class="fa fa-map-marker" aria-hidden="true"></i>
                                <div class="right-info">
                                    <b><?php echo e(trans('footer.Address')); ?></b>
                                    <p><?php echo e($setting->address); ?></p>
                                </div>
                            </div>
                        </div>



           </article> <!-- product-info-aside .// -->
                </main> <!-- col.// -->
            </div> <!-- row.// -->
        </div> <!-- card.// -->
        <!-- ============================ COMPONENT 1 END .// ================================= -->





    </div>

</section>
<?php /**PATH C:\xampp\htdocs\e-store\resources\views/livewire/contact-component.blade.php ENDPATH**/ ?>