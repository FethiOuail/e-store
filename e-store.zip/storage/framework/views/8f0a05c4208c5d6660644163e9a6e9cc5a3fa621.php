<a href="<?php echo e(route('product.wishlist')); ?>" class="widget-header mr-2">
    <div class="icon">
        <i class="icon-sm rounded-circle border fa fa-heart"></i>
        <?php if(Cart::instance("wishlist")->count() > 0): ?>
            <span class="notify">  <?php echo e(Cart::instance("wishlist")->count()); ?></span>
        <?php else: ?>

            <span class="notify">0</span>
        <?php endif; ?>

    </div>
</a>
<?php /**PATH C:\xampp\htdocs\e-store\resources\views/livewire/wishlist-count-component.blade.php ENDPATH**/ ?>