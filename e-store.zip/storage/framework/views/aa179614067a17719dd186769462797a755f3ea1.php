 <style>
        nav svg{
            height: 20px;
        }
        nav .hidden{
            display: block !important;
        }
    </style>

    <div class="container-fluid" >
        <h4 class="card-title mb-4">   <?php echo e(trans('message.AllOrders')); ?> </h4>

        <table id="example" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                            <tr>
                                <th> <?php echo e(trans('message.OrderId')); ?></th>
                                <th> <?php echo e(trans('message.Subtotal')); ?></th>
                                <th> <?php echo e(trans('message.Discount')); ?></th>
                                <th> <?php echo e(trans('message.Tax')); ?></th>
                                <th> <?php echo e(trans('message.Total')); ?></th>
                                <th> <?php echo e(trans('message.FirstName')); ?></th>
                                <th> <?php echo e(trans('message.LastName')); ?></th>
                                <th> <?php echo e(trans('message.Mobile')); ?></th>
                                <th> <?php echo e(trans('message.Email')); ?></th>
                                <th> <?php echo e(trans('message.Zipcode')); ?></th>
                                <th> <?php echo e(trans('message.Status')); ?></th>
                                <th> <?php echo e(trans('message.OrderDate')); ?></th>
                                <th> <?php echo e(trans('message.Action')); ?></th>
                            </tr>

                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($order->id); ?></td>
                                    <td><?php echo e(trans('message.dz')); ?> <?php echo e($order->subtotal); ?></td>
                                    <td><?php echo e(trans('message.dz')); ?> <?php echo e($order->discount); ?></td>
                                    <td><?php echo e(trans('message.dz')); ?> <?php echo e($order->tax); ?></td>
                                    <td><?php echo e(trans('message.dz')); ?> <?php echo e($order->total); ?></td>
                                    <td><?php echo e($order->firstname); ?></td>
                                    <td><?php echo e($order->lastname); ?></td>
                                    <td><?php echo e($order->mobile); ?></td>
                                    <td><?php echo e($order->email); ?></td>
                                    <td><?php echo e($order->zipcode); ?></td>
                                    <td><?php echo e($order->status); ?></td>
                                    <td><?php echo e($order->created_at); ?></td>
                                    <td><a href="<?php echo e(route('user.orderdetails',['order_id'=>$order->id])); ?>" class="btn btn-primary btn-sm"><?php echo e(trans('message.Details')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
        <?php echo e($orders->links()); ?>



    </div>




<?php $__env->startPush('scripts'); ?>
    <script>

        $(document).ready(function() {
            $('#example').DataTable();
        } );

    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\e-store\resources\views/livewire/user/user-orders-component.blade.php ENDPATH**/ ?>