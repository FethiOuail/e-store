
<div>
    <div class="container" style="padding: 30px 0;">


        <div class="row">
            <div class="col-md-12">
                <?php if(Session::has('order_message')): ?>
                    <div class="alert alert-success" role="alert"><?php echo e(Session::get('order_message')); ?></div>
                <?php endif; ?>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-md-6">
                                <?php echo e(trans('message.OrderDetails')); ?>

                            </div>
                            <div class="col-md-6">
                                <a href="<?php echo e(route('user.orders')); ?>" class="btn btn-primary pull-right"> <?php echo e(trans('message.MyOrders')); ?></a>
                                <?php if($order->status == 'ordered'): ?>
                                    <a href="#" wire:click.prevent="cancelOrder" style="margin-right:20px;" class="btn btn-warning pull-right"><?php echo e(trans('message.CancelOrder')); ?></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <table class="table">
                            <th>Order ID</th>
                            <td><?php echo e($order->id); ?></td>
                            <th><?php echo e(trans('message.OrderDate')); ?></th>
                            <td><?php echo e($order->created_at); ?></td>
                            <th><?php echo e(trans('message.Status')); ?></th>
                            <td><?php echo e($order->status); ?></td>
                            <?php if($order->status == 'delivered'): ?>
                                <th><?php echo e(trans('message.DeliveryDate')); ?></th>
                                <td><?php echo e($order->delivered_date); ?></td>
                            <?php elseif($order->status == 'canceled'): ?>
                                <th><?php echo e(trans('message.CanceledDate')); ?></th>
                                <td><?php echo e($order->canceled_date); ?></td>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>


        <div class="row">
            <aside class="col-lg-9">
                <div class="card">
                    <table class="table table-borderless table-shopping-cart">
                        <thead class="text-muted">
                        <tr class="small text-uppercase">
                            <th scope="col"><?php echo e(trans('message.Product')); ?></th>
                            <th scope="col" width="120"><?php echo e(trans('message.Quantity')); ?></th>
                            <th scope="col" width="120"><?php echo e(trans('message.Price')); ?></th>
                            <th scope="col" class="text-right" width="200"> </th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td>
                                <figure class="itemside align-items-center">
                                    <div class="aside"><img src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($item->product->image); ?>" alt="<?php echo e($item->product->name); ?>" class="img-sm"></div>
                                    <figcaption class="info">
                                        <a href="<?php echo e(route('product.details',['slug'=>$item->product->slug])); ?>" class="title text-dark"><?php echo e($item->product->name); ?></a>

                                    </figcaption>
                                </figure>
                            </td>
                            <td>
                                <div class="price-wrap">
                                    <var class="price"> <?php echo e($item->quantity); ?> </var>

                                </div> <!-- price-wrap .// -->
                            </td>
                            <td>
                                <div class="price-wrap">
                                    <var class="price"> <?php echo e($item->price * $item->quantity); ?> <?php echo e(trans('message.dz')); ?>   </var>
                                    <small class="text-muted"> <?php echo e($item->price); ?> <?php echo e(trans('message.each')); ?>  </small>
                                </div> <!-- price-wrap .// -->
                            </td>
                            <td class="text-right">
                                <?php if($order->status == 'delivered' && $item->rstatus == false): ?>
                                   <a href="<?php echo e(route('user.review',['order_item_id'=>$item->id])); ?>"><?php echo e(trans('message.WriteReview')); ?></a>
                                <?php endif; ?>
                            </td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <div class="card-body border-top">
                    </div> <!-- card-body.// -->

                </div> <!-- card.// -->

            </aside> <!-- col.// -->
            <aside class="col-lg-3">
                <div class="card">
                    <div class="card-header">
                    <p class="card-title text-center font-weight-bold"><?php echo e(trans('message.OrderSummary')); ?></p>
                    </div>
                    <div class="card-body">
                        <dl class="dlist-align">
                            <dt><?php echo e(trans('message.Subtotal')); ?>:</dt>
                            <dd class="text-right"> <?php echo e($order->subtotal); ?> <?php echo e(trans('message.dz')); ?>  </dd>
                        </dl>
                        <dl class="dlist-align">
                            <dt><?php echo e(trans('message.Tax')); ?> :</dt>
                            <dd class="text-right text-danger"> <?php echo e($order->tax); ?> <?php echo e(trans('message.dz')); ?> </dd>
                        </dl>
                        <dl class="dlist-align">
                            <dt><?php echo e(trans('message.Total')); ?>:</dt>
                            <dd class="text-right text-dark b"><strong> <?php echo e($order->total); ?> <?php echo e(trans('message.dz')); ?> </strong></dd>
                        </dl>
                        <hr>

                    </div> <!-- card-body.// -->
                </div> <!-- card.// -->

            </aside> <!-- col.// -->


        </div>



        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <?php echo e(trans('message.BillingDetails')); ?>

                    </div>
                    <div class="panel-body">
                        <table class="table">
                            <tr>
                                <th> <?php echo e(trans('message.FirstName')); ?> </th>
                                <td><?php echo e($order->firstname); ?></td>
                                <th> <?php echo e(trans('message.LastName')); ?> </th>
                                <td><?php echo e($order->lastname); ?></td>
                            </tr>
                            <tr>
                                <th> <?php echo e(trans('footer.Phone')); ?> </th>
                                <td><?php echo e($order->mobile); ?></td>
                                <th> <?php echo e(trans('message.Email')); ?> </th>
                                <td><?php echo e($order->email); ?></td>
                            </tr>
                            <tr>
                                <th> <?php echo e(trans('message.Line1')); ?> </th>
                                <td><?php echo e($order->line1); ?></td>
                                <th> <?php echo e(trans('message.Line2')); ?> </th>
                                <td><?php echo e($order->line2); ?></td>
                            </tr>
                            <tr>
                                <th> <?php echo e(trans('message.City')); ?> </th>
                                <td><?php echo e($order->city); ?></td>
                                <th> <?php echo e(trans('message.Province')); ?> </th>
                                <td><?php echo e($order->province); ?></td>
                            </tr>
                            <tr>
                                <th <?php echo e(trans('message.Country')); ?> ></th>
                                <td><?php echo e($order->country); ?></td>
                                <th> <?php echo e(trans('message.Zipcode')); ?> </th>
                                <td><?php echo e($order->zipcode); ?></td>
                            </tr>
                        </table>

                    </div>
                </div>
            </div>
        </div>

        <?php if($order->is_shipping_different): ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Shipping Details
                        </div>
                        <div class="panel-body">
                            <table class="table">
                                <tr>
                                    <th>First Name</th>
                                    <td><?php echo e($order->shipping->firstname); ?></td>
                                    <th>Last Name</th>
                                    <td><?php echo e($order->shipping->lastname); ?></td>
                                </tr>
                                <tr>
                                    <th>Phone</th>
                                    <td><?php echo e($order->shipping->mobile); ?></td>
                                    <th>Email</th>
                                    <td><?php echo e($order->shipping->email); ?></td>
                                </tr>
                                <tr>
                                    <th>Line1</th>
                                    <td><?php echo e($order->shipping->line1); ?></td>
                                    <th>Line2</th>
                                    <td><?php echo e($order->shipping->line2); ?></td>
                                </tr>
                                <tr>
                                    <th>City</th>
                                    <td><?php echo e($order->shipping->city); ?></td>
                                    <th>Province</th>
                                    <td><?php echo e($order->shipping->province); ?></td>
                                </tr>
                                <tr>
                                    <th>Country</th>
                                    <td><?php echo e($order->shipping->country); ?></td>
                                    <th>Zipcode</th>
                                    <td><?php echo e($order->shipping->zipcode); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <?php echo e(trans('message.Transaction')); ?>

                    </div>
                    <div class="panel-body">
                        <table class="table">
                            <tr>
                                <th><?php echo e(trans('message.TransactionMode')); ?> </th>
                                <td><?php echo e($order->transaction->mode); ?></td>
                            </tr>
                            <tr>
                                <th><?php echo e(trans('message.Status')); ?> </th>
                                <td><?php echo e($order->transaction->status); ?></td>
                            </tr>
                            <tr>
                                <th><?php echo e(trans('message.TransactionDate')); ?></th>
                                <td><?php echo e($order->transaction->created_at); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\e-store\resources\views/livewire/user/user-order-details-component.blade.php ENDPATH**/ ?>