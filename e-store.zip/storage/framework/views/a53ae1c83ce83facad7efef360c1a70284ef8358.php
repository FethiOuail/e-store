<?php $__env->startPush('scripts_top'); ?>

    <script type="text/javascript">
        /// some script

        // jquery ready start
        $(document).ready(function() {
            // jQuery code




            /////////////////  items slider. /plugins/slickslider/
            if ($('.slider-custom-slick').length > 0) { // check if element exists
                $('.slider-custom-slick').slick({
                    infinite: true,
                    slidesToShow: 2,
                    dots: true,
                    prevArrow: $('.slick-prev-custom'),
                    nextArrow: $('.slick-next-custom')
                });
            } // end if



            /////////////////  items slider. /plugins/slickslider/
            if ($('.slider-items-slick').length > 0) { // check if element exists
                $('.slider-items-slick').slick({
                    infinite: true,
                    swipeToSlide: true,
                    slidesToShow: 4,
                    dots: true,
                    slidesToScroll: 2,
                    prevArrow: '<button type="button" class="slick-prev"><i class="fa fa-chevron-left"></i></button>',
                    nextArrow: '<button type="button" class="slick-next"><i class="fa fa-chevron-right"></i></button>',
                    responsive: [
                        {
                            breakpoint: 768,
                            settings: {
                                slidesToShow: 2
                            }
                        },
                        {
                            breakpoint: 640,
                            settings: {
                                slidesToShow: 1
                            }
                        }
                    ]
                });
            } // end if



            /////////////////  items slider. /plugins/owlcarousel/
            if ($('.slider-banner-owl').length > 0) { // check if element exists
                $('.slider-banner-owl').owlCarousel({
                    loop:true,
                    margin:0,
                    items: 1,
                    dots: false,
                    nav:true,
                    navText: ["<i class='fa fa-chevron-left'></i>", "<i class='fa fa-chevron-right'></i>"],
                });
            } // end if

            /////////////////  items slider. /plugins/owlslider/
            if ($('.slider-items-owl').length > 0) { // check if element exists
                $('.slider-items-owl').owlCarousel({
                    loop:true,
                    margin:10,
                    nav:true,
                    navText: ["<i class='fa fa-chevron-left'></i>", "<i class='fa fa-chevron-right'></i>"],
                    responsive:{
                        0:{
                            items:1
                        },
                        640:{
                            items:3
                        },
                        1024:{
                            items:4
                        }
                    }
                })
            } // end if

            /////////////////  items slider. /plugins/owlcarousel/
            if ($('.slider-custom-owl').length > 0) { // check if element exists
                var slider_custom_owl = $('.slider-custom-owl');
                slider_custom_owl.owlCarousel({
                    loop: true,
                    margin:15,
                    items: 2,
                    nav: false,
                });

                // for custom navigation
                $('.owl-prev-custom').click(function(){
                    slider_custom_owl.trigger('prev.owl.carousel');
                });

                $('.owl-next-custom').click(function(){
                    slider_custom_owl.trigger('next.owl.carousel');
                });

            } // end if



        });
        // jquery end
    </script>
<?php $__env->stopPush(); ?>


<div class="container ">



    <?php
        $witems = Cart::instance('wishlist')->content()->pluck('id');
    ?>

    <br>

    <div class="card">
        <div class="row no-gutters">
            <aside class="col-md-6">
                <article class="gallery-wrap">
                    <div class="img-big-wrap"  wire:ignore>
                        <div> <a href="#"><img  id="dataimage" src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>" style="height: 350px !important;"></a></div>
                    </div> <!-- slider-product.// -->
                    <div class="thumbs-wrap">
                        <?php
                            $images = explode(",",$product->images);
                        ?>
                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($image): ?>
                        <a href="#" class="item-thumb"> <img class="imgdata" data-src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($image); ?>" src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($image); ?>"></a>

                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    </div> <!-- slider-nav.// -->
                </article> <!-- gallery-wrap .end// -->
            </aside>




            <main class="col-md-6 border-left">
                <article class="content-body">

                    <h2 class="title"> <?php echo e($product->name); ?>  </h2>

                    <style>
                        .color-gray {
                            color: #e6e6e6 !important;
                        }

                    </style>

                    <?php
                        $avgrating = 0;
                        $avgratings = 0;
                        $avg = 0;
                    ?>

                    <?php $__currentLoopData = $product->orderItems->where('rstatus', 1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php
                            $avgrating = $avgrating + $orderItem->review->rating;

                        ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    <?php
                    $avg = $avgrating * 100 / 5;

                    ?>

                    <div class="rating-wrap my-3">
                        <ul class="rating-stars">
                            <li style="width:<?php echo e($avg); ?>%" class="stars-active">
                                <i class="fa fa-star"></i> <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i> <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </li>
                            <li>
                                <i class="fa fa-star"></i> <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i> <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </li>
                        </ul>
                        <small class="label-rating text-muted"> <?php echo e($product->orderItems->where('rstatus',1)->count()); ?> <?php echo e(trans('details.reviews')); ?> </small>
                        <small class="label-rating text-success"> <i class="fa fa-clipboard-check"></i> 154  <?php echo e(trans('details.orders')); ?>  </small>
                    </div> <!-- rating-wrap.// -->

                    <div class="mb-3">
                        <var class="price h4">

                            <?php if($product->sale_price > 0 && $sale->status == 1 && $sale->sale_date > Carbon\Carbon::now()): ?>

                                <div class="wrap-price">
                                    <span class="product-price">DZ <?php echo e($product->sale_price); ?></span>
                                    <del><span class="product-price text-danger salep">DZ <?php echo e($product->regular_price); ?></span></del>
                                </div>

                            <?php else: ?>
                                <div class="wrap-price"><span class="product-price">DZ <?php echo e($product->regular_price); ?></span></div>
                            <?php endif; ?>


                        </var>
                        <span class="text-muted"> </span>
                    </div> <!-- price-detail-wrap .// -->

                    <p>   <?php echo e($product->short_description); ?> </p>

                    <div class="stock-info in-stock">
                        <p class="availability"><?php echo e(trans('details.Availability')); ?> : <b>  <?php echo e($product->stock_status); ?></b></p>
                    </div>


                    <hr>
                    <div class="form-row"  wire:ignore>
                        <div class="form-group col-md flex-grow-0">
                            <label><?php echo e(trans('details.Quantity')); ?></label>
                            <div class="input-group mb-3 input-spinner">
                                <div class="input-group-prepend">
                                    <button class="btn btn-light" type="button" id="button-plus"  wire:click.prevent="increaseQuantity"> + </button>
                                </div>
                                <input type="text" class="form-control" value="1" data-max="120" pattern="[0-9]*" wire:model="qty">
                                <div class="input-group-append">
                                    <button class="btn btn-light" type="button" id="button-minus"  wire:click.prevent="decreseQuantity"> − </button>
                                </div>
                            </div>
                        </div> <!-- col.// -->



                    </div> <!-- row.// -->

                    <?php if($product->sale_price > 0  && $sale->status == 1 && $sale->sale_date > Carbon\Carbon::now()): ?>
                        <a href="#" class="btn  btn-outline-primary" wire:click.prevent="store(<?php echo e($product->id); ?>,'<?php echo e($product->name); ?>',<?php echo e($product->sale_price); ?>)"><span class="text"><?php echo e(trans('details.Addtocart')); ?></span> <i class="fas fa-shopping-cart"></i></a>

                    <?php else: ?>
                        <a href="#" class="btn  btn-outline-primary" wire:click.prevent="store(<?php echo e($product->id); ?>,'<?php echo e($product->name); ?>',<?php echo e($product->regular_price); ?>)"><span class="text"><?php echo e(trans('details.Addtocart')); ?></span> <i class="fas fa-shopping-cart"></i></a>

                    <?php endif; ?>


                    <?php if($witems->contains($product->id)): ?>
                        <a href="#"  wire:click.prevent="removeFromWishlist(<?php echo e($product->id); ?>)" class="btn  btn-outline-danger"><span class="Add Wishlist"><?php echo e(trans('details.RemoveWishlist')); ?></span> <i class="fas fa-heart text-danger"></i></a>


                    <?php else: ?>

                        <a href="#"  wire:click.prevent="addToWishlist(<?php echo e($product->id); ?>,'<?php echo e($product->name); ?>',<?php echo e($product->regular_price); ?>)" class="btn  btn-outline-danger"><span class="Add Wishlist"><?php echo e(trans('details.AddWishlist')); ?></span> <i class="fas fa-heart text-danger"></i></a>

                    <?php endif; ?>




                </article> <!-- product-info-aside .// -->
            </main> <!-- col.// -->
        </div> <!-- row.// -->
    </div>


    <br>


    <div class="row " >

        <div class="container" >

            <div class="card " style="padding: 10px">
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true"> <?php echo e(trans('details.description')); ?> </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false"><?php echo e(trans('details.reviews')); ?> </a>
                    </li>

                </ul>
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                        <?php echo e($product->description); ?>

                    </div>
                    <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">



                        <div id="comments">
                            <h2 class="woocommerce-Reviews-title"><?php echo e($product->orderItems->where('rstatus',1)->count()); ?> <?php echo e(trans('details.reviewfor')); ?>  <span><?php echo e($product->name); ?></span></h2>
                            <ol class="commentlist">
                                <?php $__currentLoopData = $product->orderItems->where('rstatus',1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <div id="comment-20" class="">

                                            <div class="row">

                                                <div class="">
                                                    <img alt="" src="<?php echo e(asset('assets/images/avatar.jpg')); ?>" height="40" width="40">

                                                </div>

                                                <div class="col-8" style="">
                                                        <div class="rating-wrap my-3">


                                                            <ul class="rating-stars">
                                                                <li style="width:<?php echo e($avg); ?>%" class="stars-active">
                                                                    <i class="fa fa-star"></i> <i class="fa fa-star"></i>
                                                                    <i class="fa fa-star"></i> <i class="fa fa-star"></i>
                                                                    <i class="fa fa-star"></i>
                                                                </li>
                                                                <li>
                                                                    <i class="fa fa-star"></i> <i class="fa fa-star"></i>
                                                                    <i class="fa fa-star"></i> <i class="fa fa-star"></i>
                                                                    <i class="fa fa-star"></i>
                                                                </li>
                                                            </ul>
                                                            <span class="">Rated <strong class="rating"><?php echo e($orderItem->review->rating); ?></strong> out of 5</span>

                                                        </div> <!-- rating-wrap.// -->

                                                        <p class="meta">
                                                            <strong class="woocommerce-review__author"><?php echo e($orderItem->order->user->name); ?></strong>
                                                            <span class="woocommerce-review__dash">–</span>
                                                            <time class="woocommerce-review__published-date" datetime="2008-02-14 20:00" ><?php echo e(Carbon\Carbon::parse($orderItem->review->created_at)->format('d F Y g:i A')); ?></time>
                                                        </p>
                                                    <b><?php echo e($orderItem->review->comment); ?></b>
                                                        <div class="description">

                                                        </div>

                                                    </div>

                                                </div>



                                            </div>

                                    <hr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ol>
                        </div><!-- #comments -->
                    </div>
                </div>

            </div>
        </div>

    </div>

    <br><br>

    <style>

        .owl-stage-outer{
            position:relative;
            overflow:hidden;
            -webkit-transform:translate3d(0,0,0);
            direction: ltr;
        }

    </style>

    <div class="row " wire:ignore >
        <h4><?php echo e(trans('details.RelatedProducts')); ?> </h4>



        <!-- ============== COMPONENT SLIDER ITEMS OWL  ============= -->
        <div class="slider-items-owl owl-carousel owl-theme " >

            <?php $__currentLoopData = $rel_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="item-slide">


                    <figure class="card card-product-grid">
                        <div class="img-wrap">
				<span class="topbar">
				<?php if($r_product->featured): ?>	<span class="badge badge-success">  NEW </span> <?php endif; ?>
				</span>
                            <a href="<?php echo e(route('product.details',['slug'=>$r_product->slug])); ?>" title="<?php echo e($r_product->name); ?>">
                                <img src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($r_product->image); ?>">
                            </a>
                        </div>
                        <figcaption class="info-wrap border-top">
                            <a href="<?php echo e(route('product.details',['slug'=>$r_product->slug])); ?>" title="<?php echo e($r_product->name); ?>" class="title"><?php echo e(substr($r_product->name, 1, 50)); ?>.. </a>
                            <div class="price-wrap mt-2">


                                <?php if($r_product->sale_price): ?>

                                    <span class="price"><?php echo e($r_product->sale_price); ?></span>
                                    <small class="price-old "> <del><?php echo e($r_product->regular_price); ?></del></small>

                                <?php else: ?>
                                    <span class="price"> <?php echo e($r_product->regular_price); ?> - </span>
                                <?php endif; ?>


                                <span class="float-right text-danger"> <?php if( $r_product->stock_status === "outofstock"): ?> <?php echo e(trans('message.outofstock')); ?> <?php endif; ?></span>
                            </div> <!-- price-wrap.// -->
                        </figcaption>
                    </figure> <!-- card // -->

               


                </div>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </div>
        <!-- ============== COMPONENT SLIDER ITEMS OWL .end // ============= -->


    </div>

    <br><br>


</div>








<?php $__env->startPush('scripts'); ?>

    <script type="text/javascript">
        /// some script
            $('#myTab a').on('click', function (e) {
            e.preventDefault()
            $(this).tab('show')
            })


        $('.imgdata').on('click', function (e) {
            e.preventDefault()

            var  getDefaultImg = $(this).data("src");


            $("#dataimage").attr("src", getDefaultImg);

            console.log(getDefaultImg);

        })

        </script>

    <?php $__env->stopPush(); ?>





<?php /**PATH C:\xampp\htdocs\e-store\resources\views/livewire/details-component.blade.php ENDPATH**/ ?>