


<?php if (isset($component)) { $__componentOriginal6121507de807c98d4e75d845c5e3ae4201a89c9a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BaseLayout::class, []); ?>
<?php $component->withName('base-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <main id="main" class="main-site left-sidebar">

        <div class="container">


            <section class="section-pagetop bg " style="padding: 10px">
                <div class="container">
                    <h2 class="title-page"><?php echo e(trans('message.Wishlist')); ?> </h2>
                    <nav>
                        <ol class="breadcrumb text-white">
                            <li class="breadcrumb-item"><a href="/home"> <?php echo e(trans('message.home')); ?> </a></li>

                            <li class="breadcrumb-item active" aria-current="page"><?php echo e(trans('message.ResetPassword')); ?></li>
                        </ol>
                    </nav>
                </div> <!-- container //  -->
            </section>


            <div class="row justify-content-center" >
                <div class="col-6">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.validation-errors','data' => ['class' => 'mb-4']]); ?>
<?php $component->withName('jet-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                <form name="frm-login" method="POST" action="<?php echo e(route('password.update')); ?>">
                                    <?php echo csrf_field(); ?>


                                    <input type="hidden" name="token" value="<?php echo e($request->route('token')); ?>">



                                    <div class="form-group">
                                        <label for="frm-login-uname">Email Address:</label>
                                        <input type="email" class="form-control"type="email" id="frm-login-uname" name="email" placeholder="Type your email address" value="<?php echo e($request->email); ?>" required autofocus>
                                    </div> <!-- form-group// -->



                                    <div class="form-group">
                                        <label for="frm-login-uname">Password* </label>
                                        <input type="password" class="form-control" id="password" name="password" placeholder="Password" required autocomplete="new-password">
                                    </div> <!-- form-group// -->





                                    <div class="form-group">
                                        <label for="password_confirmation">Confirm Password *</label>
                                        <input type="password" class="form-control"   id="password_confirmation" name="password_confirmation" placeholder="Confirm Password" required autocomplete="new-password">
                                    </div> <!-- form-group// -->

                                    <div class="form-group">
                                    <input type="submit" class="btn btn-primary btn-block" value="Reset Password" name="submit">
                                    </div>

                                </form>

                </div>
        </div><!--end container-->

        </div>

    </main>
 <?php if (isset($__componentOriginal6121507de807c98d4e75d845c5e3ae4201a89c9a)): ?>
<?php $component = $__componentOriginal6121507de807c98d4e75d845c5e3ae4201a89c9a; ?>
<?php unset($__componentOriginal6121507de807c98d4e75d845c5e3ae4201a89c9a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\e-store\resources\views/auth/reset-password.blade.php ENDPATH**/ ?>