
<div>
    <main id="main" class="main-site">
        <section class="section-pagetop bg " style="padding: 10px">
            <div class="container">
                <nav>
                    <ol class="breadcrumb text-white">
                        <li class="breadcrumb-item"><a href="/home"> <?php echo e(trans('message.home')); ?> </a></li>

                        <li class="breadcrumb-item active" aria-current="page"><?php echo e(trans('message.ThankYou')); ?></li>
                    </ol>
                </nav>
            </div> <!-- container //  -->
        </section>
        <br>


        <div class="container">






        </div>

        <div class="container pb-60">
            <div class="row">
                <div class="col-md-12 text-center padding-y" >
                    <h2> <?php echo e(trans('message.Thankyouforyourorder')); ?> </h2>
                    <p><?php echo e(trans('message.Aconfirmationemailwassent')); ?></p>
                    <a href="/shop" class="btn btn-primary btn-submit btn-submitx"><?php echo e(trans('message.ContinueShopping')); ?></a>

                </div>
            </div>
        </div>

    </main>
</div>
<?php /**PATH C:\xampp\htdocs\e-store\resources\views/livewire/thankyou-componnent.blade.php ENDPATH**/ ?>