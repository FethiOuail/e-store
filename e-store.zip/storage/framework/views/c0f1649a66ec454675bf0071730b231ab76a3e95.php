 <main class="">

        <section class="section-pagetop bg " style="padding: 10px">
            <div class="container">
                <h2 class="title-page"><?php echo e(trans('message.Wishlist')); ?> </h2>
                <nav>
                    <ol class="breadcrumb text-white">
                        <li class="breadcrumb-item"><a href="/home"> <?php echo e(trans('message.home')); ?> </a></li>

                        <li class="breadcrumb-item active" aria-current="page"><?php echo e(trans('message.Wishlist')); ?></li>
                    </ol>
                </nav>
            </div> <!-- container //  -->
        </section>

        <div class="container padding-top" >
            <?php if(Cart::instance('wishlist')->content()->count() > 0): ?>
        <div class="row">
            <?php $__currentLoopData = Cart::instance('wishlist')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <figure class="card card-product-grid">
                    <div class="img-wrap">
                        <span class="badge badge-danger"> NEW </span>
                        <img src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($item->model->image); ?>" alt="<?php echo e($item->model->name); ?>">
                        <a class="btn-overlay" href="#"><i class="fa fa-search-plus"></i> Quick view</a>
                    </div> <!-- img-wrap.// -->
                    <figcaption class="info-wrap">
                        <div class="fix-height">
                            <a href="<?php echo e(route('product.details',['slug'=>$item->model->slug])); ?>" title="<?php echo e($item->model->regular_price); ?>" class="title"><?php echo e($item->model->name); ?></a>
                            <div class="price-wrap mt-2">

                                <span class="price"> <?php echo e($item->model->regular_price); ?> </span>
                                <del class="price-old" <?php echo e($item->model->sale_price); ?></del>
                            </div> <!-- price-wrap.// -->
                        </div>


                        <a href="#"  wire:click.prevent="moveProductFromWishlistToCart('<?php echo e($item->rowId); ?>')"  class="btn btn-block btn-primary"><?php echo e(trans('details.MoveToCart')); ?> <i class="fas fa-shopping-cart"></i> </a>
                        <a href="#" wire:click.prevent="removeFromWishlist(<?php echo e($item->model->id); ?>)"  class="btn  btn-outline-danger btn-block"><?php echo e(trans('details.RemoveWishlist')); ?>  <i class="fas fa-heart text-danger"></i></a>
                    </figcaption>
                </figure>
            </div> <!-- col.// -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </div> <!-- row end.// -->

            <?php else: ?>
                <h4><?php echo e(trans('message.Noiteminwishlist')); ?> </h4>
            <?php endif; ?>


</div>

 </main> <!-- col.// -->


<?php /**PATH C:\xampp\htdocs\e-store\resources\views/livewire/wishlist-component.blade.php ENDPATH**/ ?>