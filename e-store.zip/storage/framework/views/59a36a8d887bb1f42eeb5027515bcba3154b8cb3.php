<main id="main" class="main-site">

    <section class="section-pagetop bg " style="padding: 10px">
        <div class="container">
            <h2 class="title-page"><?php echo e(trans('message.checkout')); ?> </h2>
            <nav>
                <ol class="breadcrumb text-white">
                    <li class="breadcrumb-item"><a href="/home"> <?php echo e(trans('message.home')); ?> </a></li>

                    <li class="breadcrumb-item active" aria-current="page"><?php echo e(trans('message.checkout')); ?></li>
                </ol>
            </nav>
        </div> <!-- container //  -->
    </section>
    <br>


    <style>
        .summary-item .row-in-form input[type="password"], .summary-item .row-in-form input[type="text"], .summary-item .row-in-form input[type="tel"] {
            font-size: 13px;
            line-height: 19px;
            display: inline-block;
            height: 43px;
            padding: 2px 20px;
            max-width: 300px;
            width: 100%;
            border: 1px solid #e6e6e6;
        }
    </style>
    <div class="container">



        <form wire:submit.prevent="placeOrder" onsubmit="$('#processing').show();">
            <h2 class="title"> <?php echo e(trans('message.BillingAddress')); ?> </h2>
            <div class="form-row align-items-center">

                <div class="row col-12">
                <div class="col-12 col-sm-6 my-1">
                    <label class="" for="fname">  <?php echo e(trans('message.firstname')); ?> <span>*</span></label>
                    <input type="text" class="form-control" name="fname" value="" placeholder=" <?php echo e(trans('message.Yourname')); ?> " wire:model="firstname">
                    <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-12 col-sm-6 my-1">
                        <label class="" for="lname"> <?php echo e(trans('message.lastname')); ?> <span>*</span></label>
                        <input type="text" class="form-control" name="lname" value="" placeholder=" <?php echo e(trans('message.Yourlastname')); ?> " wire:model="lastname">
                        <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="row col-12">

                    <div class="col-12 col-sm-6 my-1">
                        <label class="" for="email"> <?php echo e(trans('message.EmailAddreess')); ?> :</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <div class="input-group-text">@</div>
                            </div>
                            <input type="email" class="form-control" name="email" value="" placeholder=" <?php echo e(trans('message.Typeyouremail')); ?> "  wire:model="email">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-12 col-sm-6 my-1">
                        <label class="" for="phone"> <?php echo e(trans('message.Phonenumber')); ?> <span>*</span></label>
                        <input type="number" class="form-control" name="phone" value="" placeholder=" <?php echo e(trans('message.digitsformat')); ?> "  wire:model="mobile">
                        <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>




                </div>


                <div class="row col-12">
                    <div class="col-12 col-sm-6 my-1">
                        <label class="" for="add"><?php echo e(trans('message.Line1')); ?>  </label>
                        <input type="text" class="form-control" name="add" value="" placeholder="<?php echo e(trans('message.Streetatapartmentnumber')); ?>  "  wire:model="line1">
                        <?php $__errorArgs = ['line1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>


                    <div class="col-12 col-sm-6 my-1">
                        <label class="" for="add"><?php echo e(trans('message.Line2')); ?> </label>
                        <input type="text" class="form-control" name="add" value="" placeholder="<?php echo e(trans('message.Streetatapartmentnumber')); ?>"  wire:model="line2">
                    </div>


                </div>


                <div class="row col-12">
                    <div class="col-12 col-sm-6 my-1">
                        <label class="" for="country"><?php echo e(trans('message.Country')); ?> <span>*</span></label>
                        <input type="text" class="form-control" name="country" value="" placeholder="Algeria" disabled wire:model="country">
                        <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>


                    <div class="col-12 col-sm-6 my-1">
                        <label class="" for="city"><?php echo e(trans('message.Province')); ?> <span>*</span></label>
                        <input type="text" class="form-control" name="province" value="" placeholder="<?php echo e(trans('message.Province')); ?>" wire:model="province">
                        <?php $__errorArgs = ['province'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                </div>



                <div class="row col-12">
                    <div class="col-12 col-sm-6 my-1">
                        <label class="" for="city"><?php echo e(trans('message.City')); ?> <span>*</span></label>
                        <input type="text" class="form-control" name="city" value="" placeholder="<?php echo e(trans('message.Cityname')); ?>" wire:model="city">
                        <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-12 col-sm-6 my-1">
                        <label class="" for="zip-code"><?php echo e(trans('message.Postcode')); ?>  </label>
                        <input type="number" class="form-control" name="zip-code" value="" placeholder="<?php echo e(trans('message.Yourpostalcode')); ?>" wire:model="zipcode">
                        <?php $__errorArgs = ['zipcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                </div>

                <div class="row col-12">
                <div class="col-auto my-1">
                    <label class="checkbox-field">
                        <input name="different-add" id="different-add" hidden value="1" type="checkbox" wire:model="ship_to_different">
                        <span hidden> <?php echo e(trans('message.Shiptoadifferentaddress')); ?> ?</span>
                    </label>
                </div>



                </div>


            </div>



            <?php if($ship_to_different): ?>
                <h3 class="box-title"> <?php echo e(trans('message.ShippingAddress')); ?> </h3>
                <div class="form-row align-items-center">

                    <div class="row col-12">
                        <div class="col-12 col-sm-6 my-1">
                            <label class="sr-only"  for="fname">first name<span>*</span></label>
                            <input type="text" class="form-control" name="fname" value="" placeholder="Your name" wire:model="s_firstname">
                            <?php $__errorArgs = ['s_firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                        <div class="col-12 col-sm-6 my-1">
                            <label class="sr-only" for="lname">last name<span>*</span></label>
                            <input type="text" class="form-control"name="lname" value="" placeholder="Your last name" wire:model="s_lastname">
                            <?php $__errorArgs = ['s_lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>

                    <div class="row col-12">

                        <div class="col-12 col-sm-6 my-1">
                            <label class="sr-only" for="email">Email Addreess:</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">@</div>
                                </div>
                                <input type="email" class="form-control"  name="email" value="" placeholder="Type your email" wire:model="s_email">
                                <?php $__errorArgs = ['s_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-12 col-sm-6 my-1">
                            <label class="sr-only" for="phone">Phone number<span>*</span></label>
                            <input type="number" class="form-control" name="phone" value="" placeholder="10 digits format" wire:model="s_mobile">
                            <?php $__errorArgs = ['s_mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>


                    <div class="row col-12">
                        <div class="col-12 col-sm-6 my-1">
                            <label class="sr-only" for="add">Line1:</label>
                            <input type="text" class="form-control" name="add" value="" placeholder="Street at apartment number" wire:model="s_line1">
                            <?php $__errorArgs = ['s_line1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="col-12 col-sm-6 my-1">
                            <label class="sr-only" for="add">Line2:</label>
                            <input type="text" class="form-control" name="add" value="" placeholder="Street at apartment number" wire:model="s_line2">
                        </div>

                    </div>


                    <div class="row col-12">
                        <div class="col-12 col-sm-6 my-1">
                            <label class="sr-only" for="country">Country<span>*</span></label>
                            <input type="text" class="form-control" name="country" value="" placeholder="United States" wire:model="s_country">
                            <?php $__errorArgs = ['s_country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="col-12 col-sm-6 my-1">
                            <label class="sr-only" for="city">Province<span>*</span></label>
                            <input type="text" class="form-control" name="province" value="" placeholder="Province" wire:model="s_province">
                            <?php $__errorArgs = ['s_province'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>




                    </div>



                    <div class="row col-12">
                        <div class="col-12 col-sm-6 my-1">
                            <label class="sr-only" for="city">Town / City<span>*</span></label>
                            <input type="text" class="form-control" name="city" value="" placeholder="City name" wire:model="s_city">
                            <?php $__errorArgs = ['s_city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-12 col-sm-6 my-1">
                            <label class="sr-only" for="zip-code">Postcode / ZIP:</label>
                            <input type="number" class="form-control" name="zip-code" value="" placeholder="Your postal code" wire:model="s_zipcode">
                            <?php $__errorArgs = ['s_zipcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>


                </div>
            <?php endif; ?>



            <div class="card">
                <h4 class="title-box"> <?php echo e(trans('message.PaymentMethod')); ?> </h4>

                <div class="card-body">
                    <dl class="dlist-align">
                        <input name="payment-method"  checked id="payment-method-bank" value="cod" type="radio" wire:model="paymentmode">
                        <span>  <?php echo e(trans('message.CashOnDelivery')); ?> </span>
                        <span class="payment-desc"> <?php echo e(trans('message.OrderNowPayonDelivery')); ?> </span>
                    </dl>
                    <?php $__errorArgs = ['paymentmode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <?php if(Session::has('checkout')): ?>
                    <dl class="dlist-align">
                        <dt> <?php echo e(trans('message.GrandTotal')); ?> </dt>
                        <dd class="text-right text-danger">DZ <?php echo e(Session::get('checkout')['total']); ?></dd>
                    </dl>
                    <?php endif; ?>

                    <?php if($errors->isEmpty()): ?>
                        <div wire:ignore id="processing" style="font-size:22px; margin-bottom:20px;padding-left:37px;color:green;display:none;">
                            <i class="fa fa-spinner fa-pulse fa-fw"></i>
                            <span> <?php echo e(trans('message.Processing')); ?> </span>
                        </div>
                    <?php endif; ?>

                    <hr>


                    <button type="submit" class="btn btn-primary btn-block"> <?php echo e(trans('message.Placeordernow')); ?>   </button>
                </div> <!-- card-body.// -->
            </div>



        </form>







    </div><!--end container-->
</main>
<?php /**PATH C:\xampp\htdocs\e-store\resources\views/livewire/checkout-component.blade.php ENDPATH**/ ?>