
<div>
    <div class="container" style="padding:30px 0;">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-md-6">
                                <?php echo e(trans('message.AllCoupon')); ?>

                            </div>
                            <div class="col-md-6">
                                <a href="<?php echo e(route('admin.addcoupon')); ?>" class="btn btn-success pull-right"><?php echo e(trans('message.Add')); ?></a>
                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <?php if(Session::has('message')): ?>
                            <div class="alert alert-success" role="alert"><?php echo e(Session::get('message')); ?></div>
                        <?php endif; ?>


                            <table id="example" class="table table-striped table-bordered" style="width:100%">
                                <thead>
                                <tr>
                                    <th>Id</th>
                                    <th><?php echo e(trans('message.CouponCode')); ?></th>
                                    <th><?php echo e(trans('message.CouponType')); ?></th>
                                    <th><?php echo e(trans('message.CouponValue')); ?></th>
                                    <th><?php echo e(trans('message.CartValue')); ?></th>
                                    <th><?php echo e(trans('message.ExpiryDate')); ?></th>
                                    <th><?php echo e(trans('message.Action')); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($coupon->id); ?></td>
                                        <td><?php echo e($coupon->code); ?></td>
                                        <td><?php echo e($coupon->type); ?></td>
                                        <?php if($coupon->type == 'fixed'): ?>
                                            <td> DZ <?php echo e($coupon->value); ?></td>
                                        <?php else: ?>
                                            <td><?php echo e($coupon->value); ?> %</td>
                                        <?php endif; ?>
                                        <td>DZ <?php echo e($coupon->cart_value); ?></td>
                                        <td><?php echo e($coupon->expiry_date); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('admin.editcoupon',['coupon_id'=>$coupon->id])); ?>"><i class="fa fa-edit fa-2x"></i></a>
                                            <a href="#" onclick="confirm('Are you sure, You want to delete this coupon?') || event.stopImmediatePropagation()" wire:click.prevent="deleteCoupon(<?php echo e($coupon->id); ?>)" style="margin-left:10px; "><i class="fa fa-times fa-2x text-danger"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                            </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->startPush('scripts'); ?>
    <script>

        $(document).ready(function() {
            $('#example').DataTable();
        } );

    </script>
<?php $__env->stopPush(); ?>

<?php /**PATH C:\xampp\htdocs\e-store\resources\views/livewire/admin/admin-coupons-component.blade.php ENDPATH**/ ?>