<div class="container">

    <div class="row">
        <div class="col-md-6">
            <h4 class="card-title mb-4">   <?php echo e(trans('message.ContactsMessages')); ?> </h4>
        </div>
        <div class="col-md-6">
        </div>
    </div>

    <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
            <th>#</th>
            <th> <?php echo e(trans('message.Name')); ?></th>
            <th> <?php echo e(trans('message.Email')); ?></th>
            <th> <?php echo e(trans('footer.Phone')); ?></th>
            <th> <?php echo e(trans('message.Comment')); ?></th>
            <th> <?php echo e(trans('message.Date')); ?></th>
        </tr>
        </thead>
        <tbody>
        <?php
            $i = 1;
        ?>
        <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i++); ?></td>
                <td><?php echo e($contact->name); ?></td>
                <td><?php echo e($contact->email); ?></td>
                <td><?php echo e($contact->phone); ?></td>
                <td><?php echo e($contact->comment); ?></td>
                <td><?php echo e($contact->created_at); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </tbody>

    </table>
    <?php echo e($contacts->links()); ?>

</div>


<?php $__env->startPush('scripts'); ?>
    <script>

        $(document).ready(function() {
            $('#example').DataTable();
        } );

    </script>
<?php $__env->stopPush(); ?>

<?php /**PATH C:\xampp\htdocs\e-store\resources\views/livewire/admin-contact-component.blade.php ENDPATH**/ ?>