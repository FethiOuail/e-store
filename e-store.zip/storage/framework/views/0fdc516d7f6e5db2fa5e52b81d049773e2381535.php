
<div>
    <style>
        nav svg{
            height: 20px;
        }
        nav .hidden{
            display: block !important;
        }
    </style>



<div class="container">

    <br>
    <div class="row">
        <div class="col-md-6">

            <?php echo e(trans('message.AllProducts')); ?>

        </div>
        <div class="col-md-6">
            <a href="<?php echo e(route('admin.addproduct')); ?>" class="btn btn-success pull-right"><?php echo e(trans('message.Add')); ?></a>

        </div>
    </div>

    <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
            <th>Id</th>
            <th><?php echo e(trans('message.Image')); ?></th>
            <th> <?php echo e(trans('message.Name')); ?></th>
            <th><?php echo e(trans('message.Stock')); ?></th>
            <th> <?php echo e(trans('message.Price')); ?></th>
            <th><?php echo e(trans('message.SalePrice')); ?></th>
            <th><?php echo e(trans('message.Category')); ?></th>
            <th><?php echo e(trans('message.Date')); ?></th>
            <th><?php echo e(trans('message.Action')); ?></th>
        </tr>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($product->id); ?></td>
                <td><img src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($product->image); ?>" width="60" /></td>
                <td><?php echo e($product->name); ?></td>
                <td><?php echo e($product->stock_status); ?></td>
                <td><?php echo e($product->regular_price); ?></td>
                <td><?php echo e($product->sale_price); ?></td>
                <td><?php echo e($product->category->name); ?></td>
                <td><?php echo e($product->created_at); ?></td>
                <td>

                    <a href="<?php echo e(route('admin.editproduct',['product_slug'=>$product->slug])); ?>"><i class="fa fa-edit fa-2x text-info"></i></a>
                    <a href="#" onclick="confirm('Are you sure, you want to delete this product?') || event.stopImmediatePropagation()" style="margin-left:10px;" wire:click.prevent="deleteProduct(<?php echo e($product->id); ?>)"><i class="fa fa-times fa-2x text-danger"></i></a>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    </table>

    <?php echo e($products->links()); ?>

</div>
<?php $__env->startPush('scripts'); ?>
    <script>

        $(document).ready(function() {
            $('#example').DataTable();
        } );

    </script>
<?php $__env->stopPush(); ?>

<?php /**PATH C:\xampp\htdocs\e-store\resources\views/livewire/admin/admin-product-component.blade.php ENDPATH**/ ?>