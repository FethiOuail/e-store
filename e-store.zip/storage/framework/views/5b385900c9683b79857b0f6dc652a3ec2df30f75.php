
<div class="container" style="padding: 0px 0">
<div class="card mx-auto" style=" margin-left: 10px; margin-right: 10px; margin-top:40px;">
    <article class="card-body">
        <header class="mb-4"><h4 class="card-title">    <?php echo e(trans('message.Settings')); ?> </h4></header>

        <?php if(Session::has('message')): ?>
            <div class="alert alert-success" role="alert"><?php echo e(Session::get('message')); ?></div>
        <?php endif; ?>
        <form class="form-horizontal" wire:submit.prevent="saveSettings">


            <div class="form-group">
                <label class="col-md-6 col-lg-4 control-label"> <?php echo e(trans('message.Email')); ?></label>
                <div class="col-md-6">
                    <input dir="ltr" type="email" placeholder=" <?php echo e(trans('message.Email')); ?>" class="form-control input-md" wire:model="email" />
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-6 col-lg-4  control-label"> <?php echo e(trans('footer.Phone')); ?></label>
                <div class="col-md-6">
                    <input dir="ltr" type="text" placeholder=" <?php echo e(trans('footer.Phone')); ?>" class="form-control input-md" wire:model="phone" />
                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-6 col-lg-4  control-label"> <?php echo e(trans('footer.Phone')); ?> 2</label>
                <div class="col-md-6">
                    <input dir="ltr" type="text" placeholder=" <?php echo e(trans('footer.Phone')); ?>2" class="form-control input-md" wire:model="phone2" />
                    <?php $__errorArgs = ['phone2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-4 col-lg-4  control-label"> <?php echo e(trans('footer.Address')); ?></label>
                <div class="col-md-6">
                    <input type="text" placeholder=" <?php echo e(trans('footer.Address')); ?>" class="form-control input-md" wire:model="address" />
                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-6 col-lg-6  control-label"> <?php echo e(trans('footer.Map')); ?></label>
                <div class="col-md-6">
                    <input dir="ltr" type="text" placeholder=" <?php echo e(trans('footer.Map')); ?>" class="form-control input-md" wire:model="map" />
                    <?php $__errorArgs = ['map'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-4 col-lg-6 control-label"> <?php echo e(trans('footer.Twitter')); ?></label>
                <div class="col-md-6">
                    <input type="text" placeholder=" <?php echo e(trans('footer.Twitter')); ?>" class="form-control input-md" wire:model="twiter" />
                    <?php $__errorArgs = ['twiter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-4  col-lg-12  control-label"> <?php echo e(trans('footer.Facebook')); ?></label>
                <div class="col-md-6">
                    <input type="text" placeholder=" <?php echo e(trans('footer.Facebook')); ?>" class="form-control input-md" wire:model="facebook" />
                    <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-4 col-lg-6  control-label">Pinterest</label>
                <div class="col-md-6">
                    <input type="text" placeholder="Pinterest" class="form-control input-md" wire:model="pinterest" />
                    <?php $__errorArgs = ['pinterest'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-4 col-lg-6 control-label"> <?php echo e(trans('footer.Instagram')); ?></label>
                <div class="col-md-6">
                    <input type="text" placeholder=" <?php echo e(trans('footer.Instagram')); ?>" class="form-control input-md" wire:model="instagram" />
                    <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-4 col-lg-6 control-label"> <?php echo e(trans('footer.Youtube')); ?></label>
                <div class="col-md-6">
                    <input type="text" placeholder=" <?php echo e(trans('footer.Youtube')); ?>" class="form-control input-md" wire:model="youtube" />
                    <?php $__errorArgs = ['youtube'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-4 col-lg-6 control-label"></label>
                <div class="col-md-6">
                    <button type="submit" class="btn btn-primary btn-block"> <?php echo e(trans('message.Save')); ?></button>
                </div>
            </div>
        </form>

    </article>

</div>
</div>
<?php /**PATH C:\xampp\htdocs\e-store\resources\views/livewire/admin/admin-setting-component.blade.php ENDPATH**/ ?>