

    <div class="container-fluid" style="padding: 30px 10px;">
        <div class="row">
                <div class="panel panel-default">
                    <div class="col-md-6">
                        <h4 class="card-title mb-4">   <?php echo e(trans('message.AllOrders')); ?> </h4>
                    </div>
                    <div class="panel-body">
                        <?php if(Session::has('order_message')): ?>
                            <div class="alert alert-success" role="alert"><?php echo e(Session::get('order_message')); ?>

                            </div>
                        <?php endif; ?>

                    </div>
                        <table id="example" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                            <tr>
                                <th> <?php echo e(trans('message.OrderId')); ?> </th>
                                <th> <?php echo e(trans('message.Subtotal')); ?> </th>
                                <th> <?php echo e(trans('message.Discount')); ?> </th>
                                <th> <?php echo e(trans('message.Tax')); ?> </th>
                                <th> <?php echo e(trans('message.Total')); ?> </th>
                                <th> <?php echo e(trans('message.FirstName')); ?> </th>
                                <th> <?php echo e(trans('message.LastName')); ?> </th>
                                <th> <?php echo e(trans('message.Mobile')); ?> </th>
                                <th> <?php echo e(trans('message.Email')); ?> </th>
                                <th> <?php echo e(trans('message.Zipcode')); ?> </th>
                                <th> <?php echo e(trans('message.Status')); ?> </th>
                                <th> <?php echo e(trans('message.OrderDate')); ?> </th>
                                <th>  <?php echo e(trans('message.Action')); ?> </th>
                            </tr>

                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($order->id); ?></td>
                                    <td>$<?php echo e($order->subtotal); ?></td>
                                    <td>$<?php echo e($order->discount); ?></td>
                                    <td>$<?php echo e($order->tax); ?></td>
                                    <td>$<?php echo e($order->total); ?></td>
                                    <td><?php echo e($order->firstname); ?></td>
                                    <td><?php echo e($order->lastname); ?></td>
                                    <td><?php echo e($order->mobile); ?></td>
                                    <td><?php echo e($order->email); ?></td>
                                    <td><?php echo e($order->zipcode); ?></td>
                                    <td><?php echo e($order->status); ?></td>
                                    <td><?php echo e($order->created_at); ?></td>

                                    <td><a href="<?php echo e(route('admin.orderdetails',['order_id'=>$order->id])); ?>" class="btn btn-info btn-sm"><?php echo e(trans('message.Details')); ?></a>

                                        <div class="dropdown">
                                            <button class="btn btn-success btn-sm dropdown-toggle" type="button" data-toggle="dropdown"><?php echo e(trans('message.Status')); ?>

                                                <span class="caret"></span></button>
                                            <ul class="dropdown-menu">
                                                <li><a href="#" wire:click.prevent="updateOrderStatus(<?php echo e($order->id); ?>,'delivered')"><?php echo e(trans('message.Delivered')); ?></a></li>
                                                <li><a href="#" wire:click.prevent="updateOrderStatus(<?php echo e($order->id); ?>,'canceled')"><?php echo e(trans('message.Canceled')); ?></a></li>
                                            </ul>
                                        </div>
                                    </td>


                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($orders->links()); ?>

                    </div>
                </div>

        </div>



    <?php $__env->startPush('scripts'); ?>
        <script>

            $(document).ready(function() {
                $('#example').DataTable();
            } );

        </script>
    <?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\e-store\resources\views/livewire/admin/admin-order-component.blade.php ENDPATH**/ ?>