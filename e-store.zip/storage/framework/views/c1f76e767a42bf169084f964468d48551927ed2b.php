<!DOCTYPE HTML>

<?php if(App::getLocale('ar') == 'ar'): ?>
    <html lang="ar" dir="rtl">

    <?php else: ?>
        <html lang="en" dir="ltr">
        <?php endif; ?>

        <head>
            <meta charset="utf-8">
            <meta http-equiv="pragma" content="no-cache" />
            <meta http-equiv="cache-control" content="max-age=604800" />
            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

            <title>MM Store</title>

            <link href="<?php echo e(asset('assets/images/favicon.ico')); ?>" rel="shortcut icon" type="image/x-icon">

            <!-- jQuery -->
            <script src="<?php echo e(asset('assets/js/jquery-2.0.0.min.js')); ?>" type="text/javascript"></script>

            <!-- Bootstrap4 files-->
            <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>" type="text/javascript"></script>



            <?php if(App::getLocale('ar') == 'ar'): ?>

                <link rel="stylesheet" href="<?php echo e(asset('assets/css/rtlbootstrap.css')); ?>"  >

            <?php else: ?>
                <link href="<?php echo e(asset('assets/css/bootstrap.css')); ?>" rel="stylesheet" type="text/css"/>
        <?php endif; ?>


            <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/DataTables/datatables.min.css')); ?>"/>



            <!-- plugin: slickslider -->
            <link href="<?php echo e(asset('assets/plugins/slickslider/slick.css')); ?>" rel="stylesheet" type="text/css" />
            <link href="<?php echo e(asset('assets/plugins/slickslider/slick-theme.css')); ?>" rel="stylesheet" type="text/css" />
            <script src="<?php echo e(asset('assets/plugins/slickslider/slick.min.js')); ?>"></script>

            <!-- plugin: owl carousel  -->
            <link href="<?php echo e(asset('assets/plugins/owlcarousel/assets/owl.carousel.css')); ?>" rel="stylesheet">
            <link href="<?php echo e(asset('assets/plugins/owlcarousel/assets/owl.theme.default.css')); ?>" rel="stylesheet">
            <script src="<?php echo e(asset('assets/plugins/owlcarousel/owl.carousel.min.js')); ?>"></script>



            <!-- Font awesome 5 -->
            <link href="<?php echo e(asset('assets/fonts/fontawesome/css/all.min.css')); ?>" type="text/css" rel="stylesheet">

            <!-- custom style -->
            <link href="<?php echo e(asset('assets/css/ui.css')); ?>" rel="stylesheet" type="text/css"/>
            <link href="<?php echo e(asset('assets/css/responsive.css')); ?>" rel="stylesheet" media="only screen and (max-width: 1200px)" />

            <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style.css')); ?>"/>

            <!-- custom javascript -->
            <script src="<?php echo e(asset('assets/js/script.js')); ?>" type="text/javascript"></script>

            <script type="text/javascript">
                /// some script

                // jquery ready start
                $(document).ready(function() {
                    // jQuery code

                });
                // jquery end
            </script>

            <?php echo $__env->yieldPushContent('scripts_top'); ?>

            <?php echo \Livewire\Livewire::styles(); ?>

        </head>
        <body>

        <?php
            $setting = DB::table('settings')->find(1)

        ?>

        <header class="section-header">

            <nav class="navbar navbar-dark navbar-expand p-0 bg-dark">
                <div class="container">
                    <ul class="navbar-nav d-none d-md-flex mr-auto">
                        <li class="nav-item"><a class="nav-link" href="#"><?php echo e(__('message.home')); ?></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"><?php echo e(trans('message.Delivery')); ?></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"><?php echo e(trans('message.Payment')); ?></a></li>
                    </ul>
                    <ul class="navbar-nav">
                        <li  class="nav-item"><a href="#" class="nav-link"> Call: <?php echo e($setting->phone); ?> </a></li>
                        <li class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"> <?php if(App::getLocale('ar') == 'ar'): ?> العربية

                                <?php else: ?>
                                    English
                                <?php endif; ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-right" style="max-width: 100px;">
                                <li><a class="dropdown-item" href="<?php echo e(route('set.language', 'ar')); ?>">Arabic</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('set.language', 'en')); ?>">English </a></li>
                            </ul>
                        </li>
                    </ul> <!-- list-inline //  -->
                </div>

            </nav> <!-- header-top-light.// -->

            <section class="header-main border-bottom">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-2 col-4">
                            <div class="brand-wrap">
                                <img class="logo" src="<?php echo e(asset('assets/images/logo.png')); ?>">
                            </div> <!-- brand-wrap.// -->
                        </div>
                        <div class="col-lg-6 col-sm-12">



                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('header-search-component')->html();
} elseif ($_instance->childHasBeenRendered('jSFPEsP')) {
    $componentId = $_instance->getRenderedChildComponentId('jSFPEsP');
    $componentTag = $_instance->getRenderedChildComponentTagName('jSFPEsP');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jSFPEsP');
} else {
    $response = \Livewire\Livewire::mount('header-search-component');
    $html = $response->html();
    $_instance->logRenderedChild('jSFPEsP', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


                        </div> <!-- col.// -->
                        <div class="col-lg-5 col-xl-4 col-sm-12">
                            <div class="widgets-wrap float-md-right">
                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('wishlist-count-component')->html();
} elseif ($_instance->childHasBeenRendered('3xJnUuY')) {
    $componentId = $_instance->getRenderedChildComponentId('3xJnUuY');
    $componentTag = $_instance->getRenderedChildComponentTagName('3xJnUuY');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('3xJnUuY');
} else {
    $response = \Livewire\Livewire::mount('wishlist-count-component');
    $html = $response->html();
    $_instance->logRenderedChild('3xJnUuY', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cart-count-component')->html();
} elseif ($_instance->childHasBeenRendered('JvieDg8')) {
    $componentId = $_instance->getRenderedChildComponentId('JvieDg8');
    $componentTag = $_instance->getRenderedChildComponentTagName('JvieDg8');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('JvieDg8');
} else {
    $response = \Livewire\Livewire::mount('cart-count-component');
    $html = $response->html();
    $_instance->logRenderedChild('JvieDg8', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                            </div>
                                <div class="widget-header icontext">
                                    <a href="#" class="icon icon-sm rounded-circle border"><i class="fa fa-user"></i></a>
                                    <div class="text">

                                        <?php if(Route::has('login')): ?>

                                            <?php if(auth()->guard()->check()): ?>

                                                <?php if(Auth::user()->utype === 'ADM'): ?>
                                                    <span class=""> <?php echo e(trans('message.Welcome')); ?>  <?php echo e(Auth::user()->name); ?></span>
                                                    <ul class="navbar-nav">

                                                    <li class="nav-item dropdown">
                                                        <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false"> My Account</a>
                                                        <div class="dropdown-menu">
                                                            <a class="dropdown-item" title="Dashboard" href="<?php echo e(route('admin.dashboard')); ?>"> <?php echo e(trans('message.Dashboard')); ?> </a>


                                                            <a  class="dropdown-item"  title="Categories" href="<?php echo e(route('admin.categories')); ?>"> <?php echo e(trans('message.Categories')); ?> </a>
                                                            <a  class="dropdown-item" title="All Products" href="<?php echo e(route('admin.products')); ?>"><?php echo e(trans('message.AllProducts')); ?></a>
                                                            <a  class="dropdown-item" title="Manage Home Slider" href="<?php echo e(route('admin.homesliders')); ?>"><?php echo e(trans('message.ManageHomeSlider')); ?></a>
                                                            <a class="dropdown-item"  title="Manage Home Categories" href="<?php echo e(route('admin.homecategories')); ?>"><?php echo e(trans('message.ManageHomeCategories')); ?></a>
                                                            <a class="dropdown-item"  href="<?php echo e(route('admin.onsale')); ?>"><?php echo e(trans('message.SaleSetting')); ?></a>


                                                            <a class="dropdown-item"  href="<?php echo e(route('admin.coupons')); ?>"> <?php echo e(trans('message.AllCoupon')); ?> </a>

                                                            <a class="dropdown-item"  href="<?php echo e(route('admin.orders')); ?>"><?php echo e(trans('message.AllOrders')); ?> </a>
                                                            <a class="dropdown-item"  href="<?php echo e(route('admin.setting')); ?>"><?php echo e(trans('message.Settings')); ?> </a>

                                                            <a class="dropdown-item"  title="Contact Us Messages" href="<?php echo e(route('admin.contact')); ?>">  <?php echo e(trans('message.ContactUsMessages')); ?></a>

                                                            <div class="dropdown-divider"></div>
                                                            <form id="logout-form" method="POST" action=" <?php echo e(route('logout')); ?> ">
                                                                <?php echo csrf_field(); ?>

                                                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">  <?php echo e(trans('message.Logout')); ?></a>

                                                            </form>
                                                        </div>
                                                    </li>
                                                <?php else: ?>

                                                            <span class=""> <?php echo e(trans('message.Welcome')); ?>  <?php echo e(Auth::user()->name); ?></span>
                                                            <ul class="navbar-nav">

                                                                <li class="nav-item dropdown">
                                                                    <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false"> My Account</a>
                                                                    <div class="dropdown-menu">

                                                                        <a  class="dropdown-item"  title="Dashboard" href="<?php echo e(route('user.dashboard')); ?>"> <?php echo e(trans('message.Dashboard')); ?>  </a>
                                                                        <a  class="dropdown-item"  title="Dashboard" href="<?php echo e(route('user.changepassword')); ?>"><?php echo e(trans('message.ChangePassword')); ?>   </a>
                                                                        <a  class="dropdown-item"  title="Dashboard" href="<?php echo e(route('user.orders')); ?>"><?php echo e(trans('message.MyOrders')); ?>   </a>




                                                                <div class="dropdown-divider"></div>
                                                                        <form id="logout-form" method="POST" action=" <?php echo e(route('logout')); ?> ">
                                                                            <?php echo csrf_field(); ?>

                                                                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><?php echo e(trans('message.Logout')); ?>  </a>

                                                                        </form>
                                                                    </div>
                                                                </li>


                                                <?php endif; ?>

                                            <?php else: ?>
                                                <div>
                                                    <a href="<?php echo e(route('login')); ?>"><?php echo e(trans('message.Signin')); ?></a>
                                                    <a href="<?php echo e(route('register')); ?>"> <?php echo e(trans('message.Register')); ?> </a>
                                                </div>
                                            <?php endif; ?>

                                        <?php endif; ?>

                                        </ul>
                                    </div>
                                </div>

                            </div> <!-- widgets-wrap.// -->
                        </div> <!-- col.// -->
                    </div> <!-- row.// -->

                </div> <!-- container.// -->


            </section> <!-- header-main .// -->


        </header> <!-- section-header.// -->


        <nav class="navbar navbar-main navbar-expand-lg navbar-light border-bottom">
            <div class="container">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main_nav" aria-controls="main_nav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="main_nav">
                    <ul class="navbar-nav">
                        <li class="nav-item dropdown">
                            <a class="nav-link pl-0" data-toggle="dropdown" href="#"><strong> <i class="fa fa-bars"></i> &nbsp <?php echo e(__('message.home')); ?> </strong></a>
                            <div class="dropdown-menu">
                                <a class="dropdown-item" href="#">Foods and Drink</a>
                                <a class="dropdown-item" href="#">Home interior</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#">Category 1</a>
                                <a class="dropdown-item" href="#">Category 2</a>
                                <a class="dropdown-item" href="#">Category 3</a>
                            </div>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="/shop"><?php echo e(trans('message.Shop')); ?> </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/cart">  <?php echo e(trans('message.Cart')); ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/checkout"> <?php echo e(trans('message.checkout')); ?> </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="#"> <?php echo e(trans('footer.About_us')); ?></a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('contact')); ?>"> <?php echo e(trans('message.contactUs')); ?></a>
                        </li>

                    </ul>
                </div> <!-- collapse .// -->
            </div> <!-- container .// -->
        </nav>




        <?php echo e($slot); ?>








        <!-- ========================= FOOTER ========================= -->

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('footer-component')->html();
} elseif ($_instance->childHasBeenRendered('OhFVdgc')) {
    $componentId = $_instance->getRenderedChildComponentId('OhFVdgc');
    $componentTag = $_instance->getRenderedChildComponentTagName('OhFVdgc');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('OhFVdgc');
} else {
    $response = \Livewire\Livewire::mount('footer-component');
    $html = $response->html();
    $_instance->logRenderedChild('OhFVdgc', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <!-- ========================= FOOTER END // ========================= -->



        <script type="text/javascript" src="<?php echo e(asset('assets/DataTables/datatables.min.js')); ?>"></script>
        <?php echo \Livewire\Livewire::scripts(); ?>



        <?php echo $__env->yieldPushContent('scripts'); ?>





        </body>


        </html>
<?php /**PATH C:\xampp\htdocs\e-store\resources\views/layouts/base.blade.php ENDPATH**/ ?>