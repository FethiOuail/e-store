
<div>
    <style>
        nav svg{
            height: 20px;
        }
        nav .hidden{
            display: block !important;
        }
    </style>

<div class="container">

    <div class="row">
        <div class="col-md-6">
            <h4 class="card-title mb-4">   <?php echo e(trans('message.AllCategories')); ?> </h4>
        </div>
        <div class="col-md-6">
            <a href="<?php echo e(route('admin.addcategory')); ?>" class="btn btn-success pull-right"><?php echo e(trans('message.Add')); ?> </a>
        </div>
    </div>

<table id="example" class="table table-striped table-bordered" style="width:100%">
    <thead>
    <tr>
        <th>Id</th>
        <th> <?php echo e(trans('message.CategoryName')); ?> </th>
        <th><?php echo e(trans('message.Slug')); ?> </th>
        <th><?php echo e(trans('message.Action')); ?></th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($category->id); ?></td>
        <td><?php echo e($category->name); ?></td>
        <td><?php echo e($category->slug); ?></td>
        <td>

            <a href="<?php echo e(route('admin.editcategory', $category->slug )); ?>" class="btn btn-success pull-right"><i class="fa fa-edit" aria-hidden="true"></i><?php echo e(trans('message.Edit')); ?> </a>

            <a href="#" onclick="confirm('Are you sure, You want to delete this category?') || event.stopImmediatePropagation()" wire:click.prevent="deleteCategory(<?php echo e($category->id); ?>)" style="margin-left:10px; "><i class="fa fa-times fa-2x text-danger"></i></a>

        </td>
    </tr>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>

</table>

    <?php echo e($categories->links()); ?>

</div>


    <?php $__env->startPush('scripts'); ?>
        <script>

            $(document).ready(function() {
                $('#example').DataTable();
            } );

        </script>
<?php $__env->stopPush(); ?>

<?php /**PATH C:\xampp\htdocs\e-store\resources\views/livewire/admin/admin-category-component.blade.php ENDPATH**/ ?>