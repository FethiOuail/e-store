
<?php if (isset($component)) { $__componentOriginal6121507de807c98d4e75d845c5e3ae4201a89c9a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BaseLayout::class, []); ?>
<?php $component->withName('base-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <!-- ========================= SECTION CONTENT ========================= -->
    <section class="section-content padding-y">

        <!-- ============================ COMPONENT REGISTER   ================================= -->
        <div class="card mx-auto" style="max-width:520px; margin-top:0px;">
            <article class="card-body">
                <header class="mb-4"><h4 class="card-title"><?php echo e(trans("message.Signup")); ?></h4></header>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.validation-errors','data' => ['class' => 'mb-4']]); ?>
<?php $component->withName('jet-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <form method="POST" action="<?php echo e(route('register')); ?>">
                <?php echo csrf_field(); ?>

                    <div class="form-row">
                        <div class="col form-group">
                            <label><?php echo e(trans("message.Yourname")); ?></label>
                            <input type="text" class="form-control" id="frm-reg-lname" name="name" placeholder="<?php echo e(trans("message.Yourname")); ?>" :value="name" required autofocus autocomplete="name">
                        </div> <!-- form-group end.// -->

                    </div> <!-- form-row end.// -->
                    <div class="form-group">
                        <label> <?php echo e(trans("message.Emailaddress")); ?></label>
                        <input type="email" class="form-control"id="frm-reg-email" name="email" placeholder="<?php echo e(trans('message.Emailaddress')); ?>" :value="email" required autofocus autocomplete="email">
                        <small class="form-text text-muted"><?php echo e(trans("message.Wellnevershareyouremailwithanyoneelse")); ?> </small>
                    </div> <!-- form-group end.// -->

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label><?php echo e(trans('message.Createpassword')); ?></label>
                            <input class="form-control" type="password" id="frm-reg-pass" name="password" placeholder="<?php echo e(trans('message.Password')); ?>" required autocomplete="new-password">
                        </div> <!-- form-group end.// -->
                        <div class="form-group col-md-6">
                            <label><?php echo e(trans('message.Repeatpassword')); ?></label>
                            <input class="form-control" type="password" id="frm-reg-cfpass"  name="password_confirmation" required autocomplete="new-password" placeholder="<?php echo e(trans('message.ConfirmPassword')); ?>">
                        </div> <!-- form-group end.// -->
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-block" value="Register" name="register"> <?php echo e(trans("message.Register")); ?>  </button>
                    </div> <!-- form-group// -->
                </form>
            </article><!-- card-body.// -->
        </div> <!-- card .// -->
        <p class="text-center mt-4"> <?php echo e(trans("message.Haveanaccount")); ?> <a href="<?php echo e(route('login')); ?>"><?php echo e(trans("message.LogIn")); ?> </a></p>
        <br><br>
        <!-- ============================ COMPONENT REGISTER  END.// ================================= -->


    </section>
    <!-- ========================= SECTION CONTENT END// ========================= -->

 <?php if (isset($__componentOriginal6121507de807c98d4e75d845c5e3ae4201a89c9a)): ?>
<?php $component = $__componentOriginal6121507de807c98d4e75d845c5e3ae4201a89c9a; ?>
<?php unset($__componentOriginal6121507de807c98d4e75d845c5e3ae4201a89c9a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\e-store\resources\views/auth/register.blade.php ENDPATH**/ ?>