
<form action="<?php echo e(route('product.search')); ?>" class="search-wrap">
    <div class="input-group w-100">
        <input type="text"  name="search" value="<?php echo e($search); ?>" class="form-control" style="width:55%;" placeholder="<?php echo e(trans('message.Search')); ?>">
        <input type="hidden" name="product_cat" value="<?php echo e($product_cat); ?>" id="product-cate">
        <input type="hidden" name="product_cat_id" value="<?php echo e($product_cat_id); ?>" id="product-cate-id">
        <select class="custom-select" name="category_name">

            <option value=""> <?php echo e(trans('message.AllCategory')); ?> </option>

            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <div class="input-group-append">
            <button class="btn btn-primary" type="submit">
                <i class="fa fa-search"></i>
            </button>
        </div>
    </div>
</form> <!-- search-wrap .end// -->
<?php /**PATH C:\xampp\htdocs\e-store\resources\views/livewire/header-search-component.blade.php ENDPATH**/ ?>