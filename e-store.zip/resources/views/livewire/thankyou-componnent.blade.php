
<div>
    <main id="main" class="main-site">
        <section class="section-pagetop bg " style="padding: 10px">
            <div class="container">
                <nav>
                    <ol class="breadcrumb text-white">
                        <li class="breadcrumb-item"><a href="/home"> {{trans('message.home')}} </a></li>

                        <li class="breadcrumb-item active" aria-current="page">{{trans('message.ThankYou')}}</li>
                    </ol>
                </nav>
            </div> <!-- container //  -->
        </section>
        <br>


        <div class="container">






        </div>

        <div class="container pb-60">
            <div class="row">
                <div class="col-md-12 text-center padding-y" >
                    <h2> {{trans('message.Thankyouforyourorder')}} </h2>
                    <p>{{trans('message.Aconfirmationemailwassent')}}</p>
                    <a href="/shop" class="btn btn-primary btn-submit btn-submitx">{{trans('message.ContinueShopping')}}</a>

                </div>
            </div>
        </div>

    </main>
</div>
