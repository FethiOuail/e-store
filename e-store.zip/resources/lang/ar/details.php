<?php

return [


    'reviews' => "التقيمات",
    'orders' => "عملية طلب",
    'Availability' => "التوفر",
    'Quantity' => "كمية. ",


    'AddWishlist' => "أضف الى قائمة الرغبات",
    'Addtocart' => "أضف إلى السلة",
    'description' => "الوصف",
    'reviewfor' => "مراجعة ل",
    'RelatedProducts' => "منتجات ذات صله ",
    'RemoveWishlist' => "إزالة من قائمة الرغبات",
    'MoveToCart' => "نقل الى السلة",


];























