<?php

return [

    'Company' => 'شركة',
    'Career' => 'مسار مهني مسار وظيفي',
    'Find_a_store' => 'ابحث عن متجر',
    'Rules_and_terms' => 'القواعد والشروط',
    'Sitemap' => 'خريطة الموقع',

    'Help' => 'مساعدة',
    'Contact_us' => 'اتصل بنا',
    'Money_refund' => 'استرداد الأموال',
    'Order_status' => 'حالة الطلب',
    'Shipping_info' => 'معلومات الشحن',
    'Open_dispute' => 'نزاع مفتوح',
    'About_us' => 'معلومات عنا',

    'Account' => 'حساب',
    'User_Login' => ' تسجيل دخول المستخدم',
    'User_register'=> 'تسجيل المستخدم',
    'Account_Setting'=> 'إعدادات الحساب',
    'My_Orders'=> 'طلباتي',


    'Social'=> 'وسائل التواصل الاجتماعي',
    'Facebook'=> 'الفيسبوك',
    'Twitter'=> 'تويتر',
    'Instagram'=> 'انستغرام',
    'Youtube'=> 'يوتيوب',
    'Map'=> 'موقع المحل في الخريظة',
    'Phone'=> 'رقم الهاتف',
    'Address'=> 'العنوان',

    ''=> '',
    ''=> '',
    ''=> '',






];
