<?php

return [


    'reviews' => "reviews",
    'orders' => "orders",
    'Availability' => "Availability",
    'Quantity' => "Quantity",
    'AddWishlist' => "Add Wish list",
    'Addtocart' => "Add to cart",
    'description' => "Description",
    'reviewfor' => "review for",
    'RelatedProducts' => "Related Products",
    'RemoveWishlist' => "Remove from Wishlist",
    'MoveToCart' => "Move To Cart",





];
















