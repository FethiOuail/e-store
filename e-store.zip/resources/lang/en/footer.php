<?php

return [



    'Company' => 'Company',
    'Career' => 'Career',
    'Find_a_store' => 'Find a store',
    'Rules_and_terms' => 'Rules and terms',
    'Sitemap' => 'Sitemap',

    'Help' => 'Help',
    'Contact_us' => 'Contact us',
    'Money_refund' => 'Money refund',
    'Order_status' => 'Order status',
    'Shipping_info' => 'Shipping info',
    'Open_dispute' => 'Open dispute',
    'About_us' => 'About us',

    'Account' => 'Account',
    'User_Login' => ' User Login',
    'User_register'=> 'User register',
    'Account_Setting'=> 'Account Setting',
    'My_Orders'=> ' My Orders',
    ''=> '',
    ''=> '',

    'Social'=> 'Social',
    'Facebook'=> 'Facebook',
    'Twitter'=> 'Twitter',
    'Instagram'=> 'Instagram',
    'Youtube'=> 'Youtube',
    'Map'=> 'Map',
    'Phone'=> 'Phone',
    'Address'=> 'Address',
    ''=> '',
    ''=> '',
    ''=> '',
    ''=> '',




];
